package examples.StarterGhostComm;

import pacman.game.Constants;

/**
 * Created by Piers on 11/11/2015.
 */
public class Sue extends POCommGhost {

    public Sue() {
        super(Constants.GHOST.SUE, 50);
    }

}
