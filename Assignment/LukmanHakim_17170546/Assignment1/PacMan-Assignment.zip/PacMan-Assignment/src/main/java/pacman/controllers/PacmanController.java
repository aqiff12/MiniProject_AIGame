package pacman.controllers;

import pacman.game.Constants;

/**
 * Essentially a tagging to make the loading of entrants easier
 */
public abstract class PacmanController extends Controller<Constants.MOVE> {
}
